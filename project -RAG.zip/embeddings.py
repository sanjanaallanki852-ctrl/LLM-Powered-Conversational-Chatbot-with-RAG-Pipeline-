from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from src.utils.config import config


def get_embeddings() -> HuggingFaceEmbeddings:
    """Return a HuggingFace sentence-transformer embedding model."""
    return HuggingFaceEmbeddings(
        model_name=config.EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def build_vectorstore(chunks: list) -> FAISS:
    """Build and persist a FAISS vectorstore from document chunks."""
    embeddings = get_embeddings()
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local(config.FAISS_INDEX_PATH)
    return vectorstore


def load_vectorstore() -> FAISS:
    """Load an existing FAISS vectorstore from disk."""
    embeddings = get_embeddings()
    return FAISS.load_local(
        config.FAISS_INDEX_PATH,
        embeddings,
        allow_dangerous_deserialization=True,
    )
