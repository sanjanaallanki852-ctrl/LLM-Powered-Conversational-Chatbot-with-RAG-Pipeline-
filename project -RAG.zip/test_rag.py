"""Basic sanity tests for document loading and splitting."""
import os
import tempfile
import pytest

from src.rag.document_loader import load_document, split_documents


def _make_txt(content: str) -> str:
    """Helper: write content to a temp .txt file and return its path."""
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False, encoding="utf-8") as f:
        f.write(content)
        return f.name


def test_load_txt_returns_documents():
    path = _make_txt("Hello world. " * 50)
    docs = load_document(path)
    assert len(docs) > 0
    assert docs[0].page_content != ""
    os.unlink(path)


def test_split_produces_multiple_chunks():
    path = _make_txt("Hello world. " * 500)
    docs = load_document(path)
    chunks = split_documents(docs)
    assert len(chunks) > 1
    os.unlink(path)


def test_unsupported_file_type_raises():
    with pytest.raises(ValueError, match="Unsupported file type"):
        load_document("somefile.docx")


def test_chunks_respect_size(monkeypatch):
    """Each chunk should not wildly exceed CHUNK_SIZE."""
    from src.utils import config as cfg_module
    monkeypatch.setattr(cfg_module.config, "CHUNK_SIZE", 200)
    monkeypatch.setattr(cfg_module.config, "CHUNK_OVERLAP", 20)

    path = _make_txt("word " * 2000)
    docs = load_document(path)
    chunks = split_documents(docs)
    for chunk in chunks:
        assert len(chunk.page_content) <= 400, "Chunk far exceeds expected size"
    os.unlink(path)
