import streamlit as st
import tempfile
import os

from src.rag.document_loader import load_document, split_documents
from src.rag.embeddings import build_vectorstore, load_vectorstore
from src.rag.chain import build_chain
from src.utils.config import config

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RAG Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("🤖 LLM-Powered RAG Chatbot")
st.caption("Ask questions grounded in your own documents using GPT + FAISS + LangChain")

# ── Sidebar: document upload ──────────────────────────────────────────────────
with st.sidebar:
    st.header("📄 Document Upload")

    uploaded_files = st.file_uploader(
        "Upload PDF or TXT files",
        type=["pdf", "txt"],
        accept_multiple_files=True,
        help="Upload one or more documents to build the knowledge base.",
    )

    process_btn = st.button("⚙️ Process Documents", use_container_width=True)

    if process_btn and uploaded_files:
        with st.spinner("Processing documents — this may take a moment..."):
            all_chunks = []
            for file in uploaded_files:
                suffix = os.path.splitext(file.name)[1]
                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(file.read())
                    tmp_path = tmp.name
                try:
                    docs = load_document(tmp_path)
                    chunks = split_documents(docs)
                    all_chunks.extend(chunks)
                except Exception as e:
                    st.error(f"Error processing {file.name}: {e}")
                finally:
                    os.unlink(tmp_path)

            if all_chunks:
                vectorstore = build_vectorstore(all_chunks)
                st.session_state["chain"] = build_chain(vectorstore)
                st.session_state["messages"] = []   # reset chat on new docs
                st.success(
                    f"✅ Ready! Indexed **{len(all_chunks)} chunks** "
                    f"from **{len(uploaded_files)} file(s)**."
                )

    elif process_btn and not uploaded_files:
        st.warning("Please upload at least one file before processing.")

    st.divider()
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state["messages"] = []
        st.rerun()

    st.markdown(
        f"""
        **Config**
        - Model: `{config.OPENAI_MODEL}`
        - Embeddings: `{config.EMBEDDING_MODEL}`
        - Chunk size: `{config.CHUNK_SIZE}` tokens
        - Top-K retrieval: `{config.TOP_K_RESULTS}`
        """
    )

# ── Chat interface ─────────────────────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state["messages"] = []

# Render history
for msg in st.session_state["messages"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# New user input
if prompt := st.chat_input("Ask a question about your documents..."):
    if "chain" not in st.session_state:
        st.warning("⚠️ Please upload and process documents first using the sidebar.")
    else:
        # Add user message
        st.session_state["messages"].append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # Generate assistant response
        with st.chat_message("assistant"):
            with st.spinner("Searching knowledge base..."):
                try:
                    result = st.session_state["chain"]({"question": prompt})
                    answer = result["answer"]
                    sources = result.get("source_documents", [])
                except Exception as e:
                    answer = f"❌ Error: {e}"
                    sources = []

            st.markdown(answer)

            if sources:
                with st.expander(f"📚 {len(sources)} source(s) retrieved"):
                    for i, doc in enumerate(sources, 1):
                        meta = doc.metadata
                        label = meta.get("source", f"Document {i}")
                        page = meta.get("page", "")
                        header = f"**[{i}]** `{label}`" + (f" — page {page}" if page != "" else "")
                        st.markdown(header)
                        st.caption(doc.page_content[:400] + "...")
                        st.divider()

        st.session_state["messages"].append({"role": "assistant", "content": answer})
