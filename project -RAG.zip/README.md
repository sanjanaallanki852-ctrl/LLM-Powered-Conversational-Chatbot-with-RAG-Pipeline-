# 🤖 LLM-Powered RAG Chatbot

An end-to-end Retrieval-Augmented Generation (RAG) chatbot using LangChain, OpenAI, FAISS, and Streamlit.

## Project Structure
```
rag-chatbot/
├── src/
│   ├── rag/
│   │   ├── document_loader.py   # PDF/TXT loading & chunking
│   │   ├── embeddings.py        # FAISS vectorstore build/load
│   │   └── chain.py             # ConversationalRetrievalChain
│   ├── ui/
│   │   └── app.py               # Streamlit interface
│   └── utils/
│       └── config.py            # Env-based config
├── data/
│   ├── uploads/                 # Raw uploaded files
│   └── processed/               # FAISS index stored here
├── tests/
│   └── test_rag.py
├── .env.example
├── requirements.txt
└── README.md
```

## Setup
```bash
# 1. Clone & enter the repo
git clone https://github.com/sanjana982/rag-chatbot
cd rag-chatbot

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY

# 5. Run the app
streamlit run src/ui/app.py
```

## Usage
1. Upload one or more PDF or TXT files via the sidebar
2. Click **Process Documents**
3. Ask questions in the chat input

## Tech Stack
- **LangChain** – orchestration & chains
- **OpenAI GPT-3.5-turbo** – LLM backbone
- **FAISS** – vector similarity search
- **Sentence Transformers** – document embeddings
- **Streamlit** – real-time chat UI
- **Python-dotenv** – config management
