from langchain_openai import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_community.vectorstores import FAISS
from src.utils.config import config


def build_chain(vectorstore: FAISS) -> ConversationalRetrievalChain:
    """
    Build a ConversationalRetrievalChain with:
    - GPT-3.5-turbo as the LLM
    - FAISS retriever with top-k results
    - Sliding window conversation memory
    """
    llm = ChatOpenAI(
        model=config.OPENAI_MODEL,
        temperature=0.2,
        openai_api_key=config.OPENAI_API_KEY,
    )

    memory = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
        output_key="answer",
    )

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": config.TOP_K_RESULTS},
    )

    chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=retriever,
        memory=memory,
        return_source_documents=True,
        verbose=False,
    )
    return chain
